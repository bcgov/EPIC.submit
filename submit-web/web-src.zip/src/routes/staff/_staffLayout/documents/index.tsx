import { Documents } from "@/components/App/Documents";
import {
  DocumentFilter,
  DocumentFilters,
} from "@/components/App/Documents/DocumentFilter";
import { PageGrid } from "@/components/Shared/PageGrid";
import { notify } from "@/components/Shared/Snackbar/snackbarStore";
import { useGetSubmittedDocuments } from "@/hooks/api/useSubmittedDocuments";
import { useGetAccountProjects } from "@/hooks/api/useProjects";
import { Box, Grid } from "@mui/material";
import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { BCDesignTokens } from "epic.theme";
import { PaginatedDocumentsResponse } from "@/models/Submission";
import { When } from "react-if";
import { ContentBox } from "@/components/Shared/Layouts/ContentBox";
import { ProjectsSelect } from "@/components/App/Projects/ProjectsSelect";

export const Route = createFileRoute("/staff/_staffLayout/documents/")({
  component: DocumentsPage,
  head: () => ({ meta: [{ title: "All Documents" }] }),
});

function DocumentsPage() {
  const [selectedProjectId, setSelectedProjectId] = useState<number | "">("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [filters, setFilters] = useState<DocumentFilters>({
    name: "",
    workPhase: [],
    submissionType: [],
    status: [],
    submittedOnStart: "",
    submittedOnEnd: "",
  });

  const { data: projectsData, isPending: isProjectsLoading } =
    useGetAccountProjects({ searchOptions: {}, pageSize: 1000 });

  const projects = useMemo(() => projectsData?.projects ?? [], [projectsData]);

  const selectedProject = useMemo(() => {
    return projects.find((p) => p.project_id === selectedProjectId);
  }, [projects, selectedProjectId]);

  useEffect(() => {
    if (projects.length === 1 && !selectedProjectId) {
      setSelectedProjectId(projects[0].project_id);
    }
  }, [projects, selectedProjectId]);

  const searchOptions = useMemo(
    () => ({
      ...(filters.name && { name: filters.name }),
      ...(filters.workPhase.length > 0 && { work_phase: filters.workPhase }),
      ...(filters.submissionType.length > 0 && {
        submission_type: filters.submissionType,
      }),
      ...(filters.status.length > 0 && { status: filters.status }),
      ...(filters.submittedOnStart && {
        submitted_on_start: filters.submittedOnStart,
      }),
      ...(filters.submittedOnEnd && {
        submitted_on_end: filters.submittedOnEnd,
      }),
    }),
    [filters],
  );

  const {
    data: documentsData,
    isPending: isDocumentsLoading,
    isError: isDocumentsError,
  } = useGetSubmittedDocuments({
    projectId: selectedProjectId === "" ? undefined : selectedProjectId,
    page: currentPage,
    size: pageSize,
    searchOptions: searchOptions as any,
  });

  const { data: unfilteredDocumentsData } = useGetSubmittedDocuments({
    projectId: selectedProjectId || undefined,
    page: 1,
    size: 1000,
    searchOptions: {} as any,
    enabled: selectedProjectId !== "",
  });

  useEffect(() => {
    if (isDocumentsError) {
      notify.error("Failed to load documents");
    }
  }, [isDocumentsError]);

  const availableStatuses = useMemo(() => {
    const data = unfilteredDocumentsData as PaginatedDocumentsResponse;
    if (!data?.items) return [];
    return Array.from(new Set(data.items.map((doc) => doc.status))).filter(
      Boolean,
    );
  }, [unfilteredDocumentsData]);

  if (isDocumentsError) {
    return <Navigate to={"/error"} />;
  }

  const handleProjectChange = (projectId: number) => {
    setSelectedProjectId(projectId);
    setCurrentPage(1);
  };

  const handleFilterChange = (newFilters: DocumentFilters) => {
    setFilters(newFilters);
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleRowsPerPageChange = (size: number) => {
    setPageSize(size);
    setCurrentPage(1);
  };

  return (
    <PageGrid>
      <Grid item xs={12}>
        <DocumentFilter
          filters={filters}
          setFilters={handleFilterChange}
          selectedProject={selectedProject}
          projectSelected={selectedProjectId !== ""}
          availableStatuses={availableStatuses}
        />
        <ContentBox mainLabel={"Documents"} contentBoxVariant="secondary">
          <ProjectsSelect
            projects={projects}
            isProjectsLoading={isProjectsLoading}
            selectedProjectId={selectedProjectId}
            filters={filters}
            onProjectChange={handleProjectChange}
          />
          <Box
            display={"flex"}
            flexDirection="column"
            sx={{
              pt: BCDesignTokens.layoutPaddingSmall,
              pb: BCDesignTokens.layoutPaddingSmall,
            }}
          >
            <When condition={selectedProjectId !== ""}>
              <Documents
                data={documentsData as PaginatedDocumentsResponse}
                isLoading={isDocumentsLoading}
                onPageChange={handlePageChange}
                onRowsPerPageChange={handleRowsPerPageChange}
              />
            </When>
          </Box>
        </ContentBox>
      </Grid>
    </PageGrid>
  );
}
