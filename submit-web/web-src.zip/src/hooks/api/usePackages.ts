import { submitRequest } from "@/utils/axiosUtils";
import {
  queryOptions,
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { Options } from "./types";
import { PackageVersion, SubmissionPackage } from "@/models/Package";
import { defaultUseQueryOptions, QUERY_KEY } from "./constants";
import { ACTIVITY_LOG_ENTITY_TYPE } from "@/models/ActivityLog";

const createSubmissionPackage = ({
  accountProjectId,
  data,
}: {
  accountProjectId: number;
  data: Record<string, unknown>;
}) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/account-projects/${accountProjectId}`,
    method: "post",
    data,
  });
};

const createNewPackageVersion = ({
  originalPackageId,
  data,
}: {
  originalPackageId: number;
  data: PackageVersion;
}) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/${originalPackageId}/versions`,
    method: "post",
    data,
  });
};

export const useCreateSubmissionPackage = (options?: Options) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createSubmissionPackage,
    ...options,
    onSuccess: (submissionPackage) => {
      if (options?.onSuccess) {
        options.onSuccess(submissionPackage);
      }
      queryClient.setQueryData(
        [QUERY_KEY.SUBMISSION_PACKAGE, submissionPackage.id],
        submissionPackage,
      );
      queryClient.invalidateQueries({
        queryKey: [
          QUERY_KEY.ACCOUNT_PROJECT,
          submissionPackage.account_project_id,
        ],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECTS],
      });
    },
  });
};

export const useCreateNewPackageVersion = (options?: Options) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createNewPackageVersion,
    ...options,
    onSuccess: (submissionPackage) => {
      if (options?.onSuccess) {
        options.onSuccess(submissionPackage);
      }
      queryClient.setQueryData(
        [QUERY_KEY.SUBMISSION_PACKAGE, submissionPackage.id],
        submissionPackage,
      );

      queryClient.invalidateQueries({
        queryKey: [
          QUERY_KEY.SUBMISSION_VERSIONS,
          submissionPackage.account_project_id,
        ],
      });

      queryClient.invalidateQueries({
        queryKey: [
          QUERY_KEY.ACCOUNT_PROJECT,
          submissionPackage.account_project_id,
        ],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECTS],
      });

      // Only invalidate version-related queries if the package has a version
      // Additional Information packages don't have versions
      if (submissionPackage.version) {
        queryClient.invalidateQueries({
          queryKey: [
            QUERY_KEY.PACKAGE_VERSIONS,
            submissionPackage.version.original_package_id,
          ],
        });

        queryClient.invalidateQueries({
          queryKey: [
            QUERY_KEY.ACTIVITY_LOGS,
            submissionPackage.version.original_package_id,
            ACTIVITY_LOG_ENTITY_TYPE.PACKAGE,
          ],
        });
      }
    },
  });
};

type GetSubmissionPackageByIdParams = {
  packageId: number;
};
export const getSubmissionPackageById = ({
  packageId,
}: GetSubmissionPackageByIdParams) => {
  return submitRequest<SubmissionPackage>({
    url: `packages/${packageId}`,
  });
};

export const getStaffSubmissionPackageById = ({
  packageId,
}: GetSubmissionPackageByIdParams) => {
  return submitRequest<SubmissionPackage>({
    url: `packages/${packageId}`,
  });
};

type UseGetSubmissionPackageByIdParams = {
  packageId: number;
  enabled?: boolean;
};

export const getSubmissionPackageQueryOptions = ({
  packageId,
  enabled = true,
}: UseGetSubmissionPackageByIdParams) =>
  queryOptions({
    queryKey: [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
    queryFn: () => getSubmissionPackageById({ packageId }),
    enabled: enabled && Boolean(packageId),
    ...defaultUseQueryOptions,
    staleTime: 0,
  });

export const getStaffSubmissionPackageQueryOptions = ({
  packageId,
  enabled = true,
}: UseGetSubmissionPackageByIdParams) =>
  queryOptions({
    queryKey: [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
    queryFn: () => getStaffSubmissionPackageById({ packageId }),
    enabled: enabled && Boolean(packageId),
    ...defaultUseQueryOptions,
    staleTime: 0,
  });

export const useGetSubmissionPackage = ({
  packageId,
  enabled = true,
}: UseGetSubmissionPackageByIdParams) => {
  const options = getSubmissionPackageQueryOptions({ packageId, enabled });
  return useQuery(options);
};

export const useGetStaffSubmissionPackage = ({
  packageId,
  enabled = true,
}: UseGetSubmissionPackageByIdParams) => {
  const options = getStaffSubmissionPackageQueryOptions({ packageId, enabled });
  return useQuery(options);
};

type GetPackageVersionsByOriginalPackageId = {
  originalPackageId?: number;
};
const getPackageVersionsByOriginalPackageId = ({
  originalPackageId,
}: GetPackageVersionsByOriginalPackageId) => {
  return submitRequest<PackageVersion[]>({
    url: `packages/${originalPackageId}/versions`,
  });
};

const addIsLatestFlag = (versions: PackageVersion[]): PackageVersion[] => {
  if (versions.length === 0) return versions;
  const maxVersion = Math.max(...versions.map((pv) => pv.version));
  return versions.map((pv) => ({
    ...pv,
    is_latest: pv.version === maxVersion,
  }));
};

type UseGetPackageVersionsByOriginalPackageIdParams = {
  originalPackageId?: number;
  enabled?: boolean;
};
export const getPackageVersionsByOriginalPackageIdQueryOptions = ({
  originalPackageId,
  enabled = true,
}: UseGetPackageVersionsByOriginalPackageIdParams) =>
  queryOptions({
    queryKey: [QUERY_KEY.PACKAGE_VERSIONS, originalPackageId],
    queryFn: () => getPackageVersionsByOriginalPackageId({ originalPackageId }),
    select: (data) => addIsLatestFlag(data),
    enabled: enabled && Boolean(originalPackageId),
  });

export const useGetPackageVersionsByOriginalPackageId = ({
  originalPackageId,
  enabled = true,
}: UseGetPackageVersionsByOriginalPackageIdParams) => {
  const options = getPackageVersionsByOriginalPackageIdQueryOptions({
    originalPackageId,
    enabled,
  });
  return useQuery(options);
};

const updateStateSubmissionPackage = ({
  packageId,
  data,
}: {
  packageId: number;
  data: Record<string, unknown>;
}) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/${packageId}/state`,
    method: "post",
    data,
  });
};

export const useUpdateStateSubmissionPackage = (options?: Options) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: updateStateSubmissionPackage,
    ...options,
    onSuccess: (submissionPackage) => {
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.SUBMISSION_PACKAGE, submissionPackage.id],
      });
      queryClient.invalidateQueries({
        queryKey: [
          QUERY_KEY.ACCOUNT_PROJECT,
          submissionPackage.account_project_id,
        ],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECTS],
      });
      queryClient.refetchQueries({
        queryKey: [QUERY_KEY.ACTIVITY_LOGS],
      });
      if (options?.onSuccess) {
        options.onSuccess();
      }
    },
  });
};

const refuseSubmissionPackage = ({
  packageId,
  data,
}: {
  packageId: number;
  data: Record<string, unknown>;
}) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/${packageId}/refuse`,
    method: "post",
    data,
  });
};

export const useRefuseSubmissionPackage = (options?: Options) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: refuseSubmissionPackage,
    ...options,
    onSuccess: (submissionPackage) => {
      if (options?.onSuccess) {
        options.onSuccess(submissionPackage);
      }
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.SUBMISSION_PACKAGE, submissionPackage.id],
      });
      queryClient.invalidateQueries({
        queryKey: [
          QUERY_KEY.SUBMISSION_VERSIONS,
          submissionPackage.account_project_id,
        ],
      });
      queryClient.invalidateQueries({
        queryKey: [
          QUERY_KEY.ACCOUNT_PROJECT,
          submissionPackage.account_project_id,
        ],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECTS],
      });
      queryClient.refetchQueries({
        queryKey: [QUERY_KEY.ACTIVITY_LOGS],
      });
    },
  });
};

const withdrawPackage = ({ packageId }: { packageId: number }) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/${packageId}/withdraw`,
    method: "post",
  });
};

export const useWithdrawPackage = (options?: Options) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: withdrawPackage,
    ...options,
    onSuccess: (submissionPackage) => {
      if (options?.onSuccess) {
        options.onSuccess(submissionPackage);
      }
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.SUBMISSION_PACKAGE, submissionPackage.id],
      });
      queryClient.invalidateQueries({
        queryKey: [
          QUERY_KEY.SUBMISSION_VERSIONS,
          submissionPackage.account_project_id,
        ],
      });
      queryClient.invalidateQueries({
        queryKey: [
          QUERY_KEY.PACKAGE_VERSIONS,
          submissionPackage.version?.original_package_id,
        ],
      });
      queryClient.invalidateQueries({
        queryKey: [
          QUERY_KEY.ACCOUNT_PROJECT,
          submissionPackage.account_project_id,
        ],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECTS],
      });
      queryClient.refetchQueries({
        queryKey: [QUERY_KEY.ACTIVITY_LOGS],
      });
    },
  });
};

const createPackageUpdateRequest = ({
  packageId,
  data,
}: {
  packageId: number;
  data: Record<string, unknown>;
}) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/${packageId}/update-request`,
    method: "post",
    data,
  });
};

const acceptUpdateRequest = ({
  packageId,
  updateRequestId,
}: {
  packageId: number;
  updateRequestId: number;
}) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/${packageId}/update-request/${updateRequestId}`,
    method: "patch",
  });
};

const withdrawUpdateRequest = ({
  packageId,
  updateRequestId,
}: {
  packageId: number;
  updateRequestId: number;
}) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/${packageId}/update-request/${updateRequestId}`,
    method: "delete",
  });
};

type UseCreatePackageUpdateRequestParams = {
  packageId: number;
  accountProjectId: number;
  options?: Options;
};
export const useCreatePackageUpdateRequest = ({
  packageId,
  accountProjectId,
  options = {},
}: UseCreatePackageUpdateRequestParams) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createPackageUpdateRequest,
    ...options,
    onSuccess: (submissionPackage) => {
      if (options?.onSuccess) {
        options.onSuccess();
      }

      queryClient.setQueryData(
        [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
        submissionPackage,
      );
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECT, accountProjectId],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECTS],
      });
    },
  });
};

const createPackageUpdateRequesNote = ({
  packageId,
  updateRequestId,
  data,
}: {
  packageId: number;
  updateRequestId: number;
  data: Record<string, unknown>;
}) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/${packageId}/update-requests/${updateRequestId}/note`,
    method: "post",
    data,
  });
};

const updatePackageUpdateRequestNote = ({
  packageId,
  updateRequestId,
  data,
}: {
  packageId: number;
  updateRequestId: number;
  data: Record<string, unknown>;
}) => {
  return submitRequest<SubmissionPackage>({
    url: `/packages/${packageId}/update-requests/${updateRequestId}/note`,
    method: "patch",
    data,
  });
};

type UseAcceptUpdateRequestParams = {
  packageId: number;
  accountProjectId: number;
  options?: Options;
};
export const useAcceptUpdateRequest = ({
  packageId,
  accountProjectId,
  options = {},
}: UseAcceptUpdateRequestParams) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: acceptUpdateRequest,
    ...options,
    onSuccess: (submissionPackage) => {
      if (options?.onSuccess) {
        options.onSuccess();
      }

      queryClient.setQueryData(
        [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
        submissionPackage,
      );
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECT, accountProjectId],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECTS],
      });
    },
  });
};

type UseWithdrawUpdateRequestParams = {
  packageId: number;
  accountProjectId: number;
  options?: Options;
};
export const useWithdrawUpdateRequest = ({
  packageId,
  accountProjectId,
  options = {},
}: UseWithdrawUpdateRequestParams) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: withdrawUpdateRequest,
    ...options,
    onSuccess: (submissionPackage) => {
      if (options?.onSuccess) {
        options.onSuccess();
      }

      queryClient.setQueryData(
        [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
        submissionPackage,
      );
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECT, accountProjectId],
      });
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.ACCOUNT_PROJECTS],
      });
    },
  });
};

type UseCreatePackageUpdateRequestNoteParams = {
  packageId: number;
  options?: Options;
};
export const useCreatePackageUpdateRequesNote = ({
  packageId,
  options = {},
}: UseCreatePackageUpdateRequestNoteParams) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createPackageUpdateRequesNote,
    ...options,
    onSuccess: (submissionPackage) => {
      if (options?.onSuccess) {
        options.onSuccess(submissionPackage);
      }
      queryClient.setQueryData(
        [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
        submissionPackage,
      );
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
      });
    },
  });
};

export const useUpdatePackageUpdateRequestNote = ({
  packageId,
  options = {},
}: UseCreatePackageUpdateRequestNoteParams) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: updatePackageUpdateRequestNote,
    ...options,
    onSuccess: (submissionPackage) => {
      if (options?.onSuccess) {
        options.onSuccess(submissionPackage);
      }
      queryClient.setQueryData(
        [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
        submissionPackage,
      );
      queryClient.invalidateQueries({
        queryKey: [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
      });
    },
  });
};
