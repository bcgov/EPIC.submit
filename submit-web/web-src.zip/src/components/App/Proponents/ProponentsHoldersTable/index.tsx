export { ProponentsHoldersTable } from "./ProponentsHoldersTable";
