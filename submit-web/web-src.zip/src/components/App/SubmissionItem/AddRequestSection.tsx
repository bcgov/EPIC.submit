import { Box, Checkbox, FormControlLabel, Typography } from "@mui/material";
import { BCDesignTokens } from "epic.theme";
import { useMemo } from "react";
import { SubmissionPackage } from "@/models/Package";
import { SubmissionItemMethod } from "@/models/SubmissionItem";
import ControlledCheckboxGroup from "@/components/Shared/ControlledFormFields/ControlledCheckboxGroup";
import ControlledTextField from "@/components/Shared/ControlledFormFields/ControlledTextField";
import { useQueryClient } from "@tanstack/react-query";
import { useParams } from "@tanstack/react-router";
import { getStaffSubmissionPackageQueryOptions } from "@/hooks/api/usePackages";
import WarningBox from "@/components/Shared/Layouts/WarningBox";
import PriorityHighIcon from "@mui/icons-material/PriorityHigh";
import Stack from "@mui/material/Stack";
import { getSubmissionItemLabel } from "@/utils";

type AddRequestSectionProps = {
  readonly disabled?: boolean;
};
export default function AddRequestSection({
  disabled = false,
}: AddRequestSectionProps) {
  const { submissionPackageId } = useParams({
    from: "/staff/_staffLayout/projects/$projectId/_projectLayout/submission-packages/$submissionPackageId/_submissionLayout/submissions/$submissionId",
  });

  const queryClient = useQueryClient();
  const submissionPackage = queryClient.getQueryData<SubmissionPackage>(
    getStaffSubmissionPackageQueryOptions({
      packageId: Number(submissionPackageId),
    }).queryKey,
  );
  const filteredItems = useMemo(() => {
    if (!submissionPackage?.items) return [];
    return submissionPackage.items.filter(
      (item) =>
        item.type.submission_method === SubmissionItemMethod.DOCUMENT_UPLOAD,
    );
  }, [submissionPackage?.items]);

  return (
    <Box
      sx={{
        border: `1px solid ${BCDesignTokens.supportBorderColorWarning}`,
        backgroundColor: "#FFF",
        padding: "8px 16px",
        borderRadius: "4px",
      }}
    >
      <Typography variant="body1" fontWeight={"bold"}>
        Revision Required for
      </Typography>
      <ControlledCheckboxGroup
        name="update_request.submission_item_types"
        disabled={disabled}
      >
        {filteredItems.map((item) => (
          <FormControlLabel
            key={item.id}
            control={<Checkbox value={item.type_id} />}
            label={getSubmissionItemLabel(item.type.name)}
          />
        ))}
      </ControlledCheckboxGroup>
      <Box sx={{ mb: BCDesignTokens.layoutMarginMedium }}>
        <Typography variant="body1" fontWeight={"bold"}>
          EAO Comment
        </Typography>
        <ControlledTextField
          name="update_request.reason"
          variant="outlined"
          multiline
          fullWidth
          minRows={4}
          sx={{
            "& .MuiInputBase-root": {
              borderColor: BCDesignTokens.typographyColorDisabled,
            },
            marginBottom: 0,
          }}
          disabled={disabled}
        />
      </Box>
      <WarningBox mb={BCDesignTokens.layoutMarginXsmall}>
        <Stack direction="row" alignItems="center" spacing={2}>
          <PriorityHighIcon fontSize="large" />
          <Typography variant="body1" color="inherit">
            This request, including the EAO Comment, will be sent to the holder
            after a Manager confirms the decision.
          </Typography>
        </Stack>
      </WarningBox>
    </Box>
  );
}
