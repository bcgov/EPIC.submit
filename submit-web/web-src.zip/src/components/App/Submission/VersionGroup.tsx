import { QUERY_KEY } from "@/hooks/api/constants";
import {
  getStaffSubmissionPackageById,
  getSubmissionPackageById,
  useGetPackageVersionsByOriginalPackageId,
  useCreateNewPackageVersion,
  useGetStaffSubmissionPackage,
  useGetSubmissionPackage,
} from "@/hooks/api/usePackages";
import {
  PackageVersion,
  SubmissionPackage,
  SubmissionPackageApprovalType,
} from "@/models/Package";
import { USER_TYPE } from "@/models/User";
import { useAccount } from "@/store/accountStore";
import {
  Backdrop,
  Button,
  CircularProgress,
  Skeleton,
  Stack,
} from "@mui/material";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import GppGoodOutlinedIcon from "@mui/icons-material/GppGoodOutlined";
import AddIcon from "@mui/icons-material/Add";
import { useModal } from "@/components/Shared/Modals/modalStore";
import ConfirmationModal from "@/components/Shared/Modals/ConfirmationModal";
import { notify } from "@/components/Shared/Snackbar/snackbarStore";
import { usePackageTableStore } from "./packageTableStore";
import {
  canProponentCreateNewVersion,
  calculateIsLatestVersion,
} from "./versionGroupUtils";

type VersionGroupProps = Readonly<{
  currentPackageVersion: PackageVersion;
}>;

export default function VersionGroup({
  currentPackageVersion,
}: VersionGroupProps) {
  const { userType } = useAccount();
  const isProponent = userType === USER_TYPE.PROPONENT;
  const [isLoading, setIsLoading] = useState(false);
  const { projectId: accountProjectIdParam, submissionPackageId } = useParams({
    strict: false,
  });
  const packageId = Number(submissionPackageId);
  const { setOpen: setOpenModal } = useModal();

  const navigate = useNavigate();
  const { reset } = usePackageTableStore();
  const { data: packageVersions, isPending: isVersionsLoading } =
    useGetPackageVersionsByOriginalPackageId({
      originalPackageId: currentPackageVersion.original_package_id,
    });
  const { data: proponentPackage } = useGetSubmissionPackage({
    packageId: Number(submissionPackageId),
    enabled: isProponent,
  });

  const { data: staffPackage, isFetching: isPackageLoading } =
    useGetStaffSubmissionPackage({
      packageId: submissionPackageId,
      enabled: !isProponent,
    });

  const submissionPackage = isProponent ? proponentPackage : staffPackage;

  const queryClient = useQueryClient();
  const loadNewPackage = async (packageId: number) => {
    try {
      setIsLoading(true);
      await queryClient.ensureQueryData<SubmissionPackage>({
        queryKey: [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
        queryFn: () =>
          isProponent
            ? getSubmissionPackageById({ packageId })
            : getStaffSubmissionPackageById({ packageId }),
      });
      navigate({
        to: `/${isProponent ? "proponent" : "staff"}/projects/${accountProjectIdParam}/submission-packages/${packageId}`,
        replace: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const { mutate: createNewPackageVersion, isPending: isCreatingPackage } =
    useCreateNewPackageVersion({
      onSuccess: (newPackage) => {
        notify.success("New package created successfully");

        // Invalidate the old package so it's refetched when revisited
        queryClient.invalidateQueries({
          queryKey: [QUERY_KEY.SUBMISSION_PACKAGE, packageId],
        });

        loadNewPackage(newPackage.id);
      },
      onError: () => {
        notify.error("Failed to create new package");
      },
    });

  function handleUpdatePackageId(newPackageId: number) {
    reset();
    loadNewPackage(newPackageId);
  }

  const handleCreateNewPackage = () => {
    setOpenModal(
      <ConfirmationModal
        title="New Submission Package"
        description={
          "This option will create another package so the Holder can resubmit documents. If a review is in progress, it will be cancelled, and the review will have to start over again when the Holder submits a new package.\nDo you want to cancel the current review and create a new package?"
        }
        confirmText="Create New Package"
        onConfirm={() => {
          createNewPackageVersion({
            originalPackageId: currentPackageVersion.original_package_id,
            data: {
              ...currentPackageVersion,
              package_id: packageId,
            },
          });
        }}
      />,
    );
  };

  const handleProponentCreateNewPackage = () => {
    setOpenModal(
      <ConfirmationModal
        title="Create New Submission Package"
        description={
          "This option will create another submission package so you can resubmit documents. " +
          "This new submission will go through the review process. " +
          "Until this new package is successfully reviewed by the EAO, the last successfully " +
          "reviewed submission is the one considered enforceable by the EAO.\n\n" +
          "Do you want to create a new package?"
        }
        confirmText="Create New Package"
        onConfirm={() => {
          createNewPackageVersion({
            originalPackageId: currentPackageVersion.original_package_id,
            data: {
              ...currentPackageVersion,
              package_id: packageId,
            },
          });
        }}
      />,
    );
  };

  const latestApprovedPackageVersion = packageVersions?.find(
    (packageVersion) =>
      packageVersion.is_approved || packageVersion.is_enforceable,
  );

  const isLatestVersion = useMemo(() => {
    return calculateIsLatestVersion(
      packageVersions,
      currentPackageVersion.version,
    );
  }, [packageVersions, currentPackageVersion.version]);

  const canProponentCreateVersion = useMemo(() => {
    return canProponentCreateNewVersion({
      isProponent,
      isLatestVersion,
      packageStatus: submissionPackage?.status,
    });
  }, [isProponent, isLatestVersion, submissionPackage?.status]);

  const canCreateVersion =
    submissionPackage?.type.approval_type !== SubmissionPackageApprovalType.C;

  const hideVersions =
    packageVersions?.length === 1 &&
    submissionPackage?.type.approval_type === SubmissionPackageApprovalType.C;

  if (isVersionsLoading || isPackageLoading) {
    return (
      <Stack direction="row" spacing={1}>
        <Skeleton variant="rectangular" width={35} height={35} />
        <Skeleton variant="rectangular" width={35} height={35} />
      </Stack>
    );
  }

  return (
    <Stack direction="row" spacing={1}>
      <Backdrop
        sx={(theme) => ({ color: "#fff", zIndex: theme.zIndex.drawer + 1 })}
        open={isLoading}
      >
        <CircularProgress color="inherit" />
      </Backdrop>
      {!isProponent && isLatestVersion && canCreateVersion && (
        <Button
          color="secondary"
          sx={{
            width: "auto",
          }}
          onClick={handleCreateNewPackage}
          startIcon={<AddIcon />}
        >
          New
        </Button>
      )}
      {canProponentCreateVersion && canCreateVersion && (
        <Button
          color="secondary"
          sx={{ width: "auto" }}
          onClick={handleProponentCreateNewPackage}
          startIcon={<AddIcon />}
          disabled={isCreatingPackage}
        >
          New Submission
        </Button>
      )}

      {!hideVersions &&
        packageVersions?.map((packageVersion) => (
          <Button
            key={packageVersion.id}
            color={
              packageId === packageVersion.package_id ? "primary" : "secondary"
            }
            sx={{
              width: "auto",
            }}
            onClick={() => handleUpdatePackageId(packageVersion.package_id)}
            startIcon={
              packageVersion.id === latestApprovedPackageVersion?.id ? (
                <GppGoodOutlinedIcon />
              ) : undefined
            }
          >
            Package {packageVersion.version}
          </Button>
        ))}
    </Stack>
  );
}
