import { Box, List, ListItem, Typography } from "@mui/material";
import WarningBox from "@/components/Shared/Layouts/WarningBox";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import { BCDesignTokens } from "epic.theme";
import ConfirmationModal from "@/components/Shared/Modals/ConfirmationModal";

type AcknowledgeSubmissionModalProps = {
  onConfirm: () => void;
  onCancel: () => void;
  hasOpenUpdateRequests: boolean;
  openRequestSectionNames: string[];
};

const AcknowledgeSubmissionModal = ({
  onConfirm,
  onCancel,
  hasOpenUpdateRequests,
  openRequestSectionNames,
}: AcknowledgeSubmissionModalProps) => {
  return (
    <ConfirmationModal
      title="Acknowledge Submission"
      onConfirm={onConfirm}
      onSecondaryAction={onCancel}
      confirmText="Confirm Acknowledgement"
      secondaryActionText="Cancel"
      description={
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 2,
            width: "520px",
          }}
        >
          {hasOpenUpdateRequests ? (
            <>
              <WarningBox sx={{ p: 1.5 }}>
                <Box sx={{ display: "flex", gap: 1.5 }}>
                  <ErrorOutlineIcon
                    sx={{ color: BCDesignTokens.supportBorderColorWarning }}
                  />
                  <Box>
                    <Typography variant="body1" sx={{ fontWeight: 700 }}>
                      Open Update Requests
                    </Typography>
                    <Typography variant="body2">
                      The following sections have open update requests:
                    </Typography>
                    <List sx={{ listStyleType: "disc", pl: 4, py: 0 }}>
                      {openRequestSectionNames.map((sectionName, index) => (
                        <ListItem
                          key={index}
                          sx={{ display: "list-item", p: 0, fontWeight: 700 }}
                        >
                          {sectionName}
                        </ListItem>
                      ))}
                    </List>
                  </Box>
                </Box>
              </WarningBox>
              <Typography variant="body1">
                The proponent will receive an email acknowledging receipt of the submission, but the package will remain open until all open update requests are either withdrawn or until documents are resubmitted and acknowledged.
              </Typography>
            </>
          ) : (
            <>
              <Typography variant="body1">
                The proponent will receive an automated email confirming the EAO
                has acknowledged receipt of the submission. Once acknowledged,
                the proponent will no longer be able to submit additional
                documents.
              </Typography>
              <Typography variant="body1">
                If you need to allow the proponent to resubmit some documents,
                you can send an Update Request before or after acknowledging the
                submission. When an Update Request is open, the submission
                package will remain open for the proponent to resubmit
                documents.
              </Typography>
            </>
          )}
        </Box>
      }
    />
  );
};

export default AcknowledgeSubmissionModal;
