"""management plan review service."""
from datetime import datetime, UTC

from flask import current_app

from submit_api.enums.activity_type import ActivityActionType
from submit_api.enums.item_status import ItemStatus
from submit_api.enums.management_plan import ManagementPlanSubmissionPurpose
from submit_api.exceptions import ResourceNotFoundError
from submit_api.models import PackageVersion, SubmissionReview, SubmissionReviewEntry
from submit_api.models import Package as PackageModel
from submit_api.models import PackageMetadata
from submit_api.models.package import PackageStatus
from submit_api.models.package_metadata import PackageMetadataFields
from submit_api.models.submission_review_entry import SubmissionReviewEntryType
from submit_api.models.update_request import UpdateRequestType, UpdateRequest
from submit_api.services.activity_log_service import ActivityLogService
from submit_api.utils.token_info import TokenInfo
from submit_api.utils.constants import (
    MANAGEMENT_PLAN_UPDATE_REQUEST_CREATED_EMAIL_TEMPLATE)
from submit_api.services.package_version_service import PackageVersionService


class ManagementPlanService:
    """management plan review service."""

    @classmethod
    def reject_management_plan_form(cls, item, session):
        """Reject management plan form."""
        cls.update_item_status_mp_rejection(item)
        cls.update_package_metadata_mp_rejection(item, session)
        cls.create_new_package_version(item, session)
        cls._log_management_plan_rejection_activity(item, session)
        cls.deactivate_update_requests(item.package_id, session)
        cls._create_rejection_email_queue(
            item.package_id, MANAGEMENT_PLAN_UPDATE_REQUEST_CREATED_EMAIL_TEMPLATE, session)
        current_app.logger.info(
            f"Management plan form rejected for item {item.id}.")
        return item

    @classmethod
    def prepare_update_request_data(cls, new_item, old_item):
        """Prepare the update request data."""
        item_review = SubmissionReview.get_active_review_by_item_id(
            old_item.id)
        manager_review_entry = SubmissionReviewEntry.get_review_entry_by_id_and_type(
            item_review.id, SubmissionReviewEntryType.MANAGER_CONFIRMATION
        )
        return {
            'package_id': new_item.package_id,
            'submission_item_types': manager_review_entry.entry.get('submission_item_types')
            if manager_review_entry else None,
            'reason': manager_review_entry.entry.get('reason') if manager_review_entry else None,
            'type': UpdateRequestType.REVIEW,
        }

    @classmethod
    def _log_management_plan_rejection_activity(cls, item, session):
        """Log activity for management plan rejection."""
        current_app.logger.info(
            f"Logging activity for management plan rejection for package {item.package_id}.")
        package = PackageModel.find_by_id(item.package_id)
        if package.version:
            ActivityLogService.log_activity(
                entity_id=package.version.original_package_id,
                action=ActivityActionType.MP_REVIEW_FAILED.value,
                entity_version=package.version.version,
                session=session
            )
        current_app.logger.info(
            f"Activity logged for management plan rejection for package {package.id}.")

    @classmethod
    def update_item_status_mp_rejection(cls, item):
        """Update the status and review date of the item for rejection."""
        current_app.logger.info(
            f"Rejecting management plan form for item {item.id}.")
        item.status = ItemStatus.REVIEW_REJECTED.value
        reviewed_on = datetime.now(UTC)
        item.reviewed_on = reviewed_on
        current_app.logger.info(
            f"Management plan form rejected for item {item.id}.")

    @classmethod
    def update_package_metadata_mp_rejection(cls, item, session):
        """Update package metadata with review completion date for rejection."""
        current_app.logger.info(
            f"Updating package metadata for package {item.package_id}.")
        package_metadata = PackageMetadata.get_or_create(item.package_id)
        reviewed_on = item.reviewed_on
        existing_json = package_metadata.json if package_metadata.json else {}
        package_metadata.json = {
            **existing_json,
            PackageMetadataFields.REVIEW_COMPLETED_ON.value: reviewed_on.isoformat(),
        }

        session.add(item)
        session.add(package_metadata)
        session.flush()
        current_app.logger.info(
            f"Package metadata updated for package {item.package_id}.")

    @classmethod
    def create_new_package_version(cls, item, session):
        """Create a new package version and retrieve new management plan item for rejection."""
        current_app.logger.info(
            f"Creating new package version for item {item.id}.")
        package = PackageModel.find_by_id(item.package_id)
        package_version = PackageVersion.get_by_id(package.version_id)
        if not package_version:
            current_app.logger.error(
                f"Package version not found for item {item.id}.")
            raise ResourceNotFoundError(
                f"Package version not found for item {item.id}.")
        new_package = PackageVersionService.create_new_package_version(package.id, session)
        PackageVersionService.copy_contact_information(package, new_package)
        new_package.status = [PackageStatus.REVISION_REQUIRED.value]
        current_app.logger.info(
            f"New package version created for {new_package.name}.")
        new_items = new_package.items
        new_item = next(
            (i for i in new_items if i.type.name == item.type.name), None)
        if not new_item:
            current_app.logger.error(
                f"{item.type.name} item not found in new package {new_package.id}.")
            raise ResourceNotFoundError(
                f"{item.type.name} item not found in new package {new_package.id}.")
        session.add(new_package)
        session.flush()
        current_app.logger.info(
            f"New package version created for {new_package.name}.")
        return new_package, new_item

    @classmethod
    def create_mp_update_request(cls, data, session):
        """Create an update request."""
        current_app.logger.info(
            f"Creating update request for new management plan {data.get('package_id')}.")
        update_request = UpdateRequest(
            submission_package_id=data.get('package_id'),
            submission_item_types=data.get('submission_item_types'),
            created_by=TokenInfo.get_username(),
            reason=data.get('reason'),
            type=data.get('type')
        )
        session.add(update_request)
        current_app.logger.info(
            f"Update request created for new management plan {data.get('package_id')}.")

    @classmethod
    def approve_management_plan(cls, item, session):
        """Approve management plan."""
        package = PackageModel.find_by_id(item.package_id)
        cls.update_item_status_mp_approval(item, package, session)
        cls.update_package_for_completion(item, package, session)
        cls.deactivate_update_requests(package.id, session, package)
        cls._log_activity_mp_approval(package, session)
        current_app.logger.info(
            f"Management plan form approved for item {item.id}.")
        return item

    @classmethod
    def require_revision_management_plan(cls, item, session):
        """Require revision for management plan."""
        cls.update_item_status_mp_revision_required(item)
        cls.update_package_metadata_mp_rejection(item, session)
        cls.create_new_package_version(item, session)
        cls._log_management_plan_revision_required_activity(item, session)
        cls.deactivate_update_requests(item.package_id, session)
        cls._create_rejection_email_queue(
            item.package_id, MANAGEMENT_PLAN_UPDATE_REQUEST_CREATED_EMAIL_TEMPLATE, session)

        # Make all package versions not enforceable
        package = PackageModel.find_by_id(item.package_id)
        package_versions = PackageVersion.get_all_by_original_package_id(package.version.original_package_id)
        for pv in package_versions:
            pv.package.enforceable = False
            session.add(pv)

        # Make previous package enforceable
        package.enforceable = True
        session.add(package)
        session.flush()

        current_app.logger.info(
            f"Management plan form requires revision for item {item.id}.")
        return item

    @classmethod
    def update_item_status_mp_revision_required(cls, item):
        """Update the status and review date of the item for revision required."""
        current_app.logger.info(
            f"Requiring revision for management plan form for item {item.id}.")
        item.status = ItemStatus.REVISION_REQUIRED
        reviewed_on = datetime.now(UTC)
        item.reviewed_on = reviewed_on
        current_app.logger.info(
            f"Management plan form requires revision for item {item.id}.")

    @classmethod
    def _log_management_plan_revision_required_activity(cls, item, session):
        """Log activity for management plan requiring revision."""
        current_app.logger.info(
            f"Logging activity for management plan requiring revision for package {item.package_id}.")
        package = PackageModel.find_by_id(item.package_id)
        if package.version:
            ActivityLogService.log_activity(
                entity_id=package.version.original_package_id,
                action=ActivityActionType.MP_REVISION_REQUIRED.value,
                entity_version=package.version.version,
                session=session
            )
        current_app.logger.info(
            f"Activity logged for management plan requiring revision for package {package.id}.")

    @staticmethod
    def get_package_submitted_to_eao_for(package):
        """Get the condition from the package."""
        current_app.logger.info(
            f"Retrieving submitted_to_eao_for for package {package.id}.")
        package_metadata = package.meta
        condition = package_metadata.json.get(
            PackageMetadataFields.MAIN_CONDITION.value)
        if not condition:
            raise ResourceNotFoundError(
                f"Condition not found for package {package.id}.")
        attributes = condition.get('condition_attributes')
        if not attributes:
            raise ResourceNotFoundError(
                f"condition_attributes key not found for package {package.id}.")
        submitted_to_eao_for = attributes.get('submitted_to_eao_for')
        if not submitted_to_eao_for:
            raise ResourceNotFoundError(
                f"submitted_to_eao_for key not found for package {package.id}.")
        current_app.logger.info(
            f"Retrieved submitted_to_eao_for for package {package.id}.")
        return submitted_to_eao_for

    @classmethod
    def update_item_status_mp_approval(cls, item, package, session):
        """Update the status of the item for approval."""
        current_app.logger.info(
            f"Approving management plan form for item {item.id}.")
        submitted_to_eao_for = cls.get_package_submitted_to_eao_for(package)

        mp_purpose_status_map = {
            ManagementPlanSubmissionPurpose.ACCEPTANCE.value: ItemStatus.ACCEPTED,
            ManagementPlanSubmissionPurpose.APPROVAL.value: ItemStatus.APPROVED,
            ManagementPlanSubmissionPurpose.SATISFACTION.value: ItemStatus.SATISFIED,
            ManagementPlanSubmissionPurpose.REVIEW.value: ItemStatus.REVIEWED,
        }
        status = mp_purpose_status_map.get(submitted_to_eao_for)
        if not status:
            raise ResourceNotFoundError(
                f"Unsupported purpose {submitted_to_eao_for} for package {package.id}.")
        item.status = status
        session.add(item)
        session.flush()
        current_app.logger.info(
            f"Management plan form {status.value} for item {item.id}.")

    @classmethod
    def update_package_for_completion(cls, item, package, session):
        """Update package for completion."""
        current_app.logger.info(
            f"Updating package for completion for item {item.id}.")
        package.completed_on = datetime.now(UTC)
        session.add(package)
        session.flush()
        current_app.logger.info(
            f"Package updated for completion for item {item.id}.")

    @classmethod
    def _log_activity_mp_approval(cls, package, session):
        """Log activity for management plan approval."""
        current_app.logger.info(
            f"Logging activity for management plan approval for package {package.id}.")
        submitted_to_eao_for = cls.get_package_submitted_to_eao_for(package)
        activity_type_condition_map = {
            ManagementPlanSubmissionPurpose.ACCEPTANCE.value: ActivityActionType.MP_ACCEPTED.value,
            ManagementPlanSubmissionPurpose.APPROVAL.value: ActivityActionType.MP_APPROVED.value,
            ManagementPlanSubmissionPurpose.SATISFACTION.value: ActivityActionType.MP_SATISFIED.value,
            ManagementPlanSubmissionPurpose.REVIEW.value: ActivityActionType.MP_REVIEWED.value,
        }
        action_type = activity_type_condition_map.get(submitted_to_eao_for)
        if not action_type:
            raise ResourceNotFoundError(
                f"Unsupported purpose {submitted_to_eao_for} for package {package.id}.")
        if package.version:
            ActivityLogService.log_activity(
                entity_id=package.version.original_package_id,
                action=action_type,
                entity_version=package.version.version,
                session=session
            )
        current_app.logger.info(
            f"Activity logged for management plan approval for package {package.id}.")

    @classmethod
    def deactivate_update_requests(cls, package_id, session, package=None):
        """Deactivate all update requests for the package."""
        PackageVersionService.deactivate_update_requests(package_id, session, package)

    @classmethod
    def _create_rejection_email_queue(cls, package_id, template_name, session):
        """Create an email queue record for an update request."""
        PackageVersionService.create_email_queue(package_id, template_name, session=session)
