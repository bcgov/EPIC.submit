"""Submission item note document model class.

Manages the submission item notes.
"""

from __future__ import annotations

from sqlalchemy import Column, Text

from .base_model import BaseModel
from .db import db


class SubmissionItemNote(BaseModel):
    """Definition of the submitted documents entity."""

    __tablename__ = "submission_item_notes"

    id = Column(db.Integer, primary_key=True, autoincrement=True)
    note = Column(Text, nullable=False)
    item_id = Column(db.Integer, db.ForeignKey("items.id", ondelete='CASCADE'), nullable=False)
    created_by = Column(db.String, db.ForeignKey("users.auth_guid"), nullable=True)
    created_by_user = db.relationship("User", foreign_keys=[created_by], lazy="joined")
