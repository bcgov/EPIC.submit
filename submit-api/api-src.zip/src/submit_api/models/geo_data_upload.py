# Copyright © 2024 Province of British Columbia
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""GeoDataUpload model class.

Manages the geo data upload entity.
"""
from __future__ import annotations

from datetime import datetime, UTC

from sqlalchemy import Boolean, Column, DateTime, Float, Integer, JSON, String, Text

from .base_model import BaseModel


class GeoDataUpload(BaseModel):  # pylint: disable=too-many-instance-attributes
    """Definition of the GeoDataUpload entity."""

    __tablename__ = 'geo_data_uploads'

    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(255), nullable=False)
    file_type = Column(String(10), nullable=True)  # 'shp' or 'zip'
    file_size_kb = Column(Float, nullable=True)
    raw_s3_key = Column(String(512), nullable=True)
    preview_s3_key = Column(String(512), nullable=True)
    standard_s3_key = Column(String(512), nullable=True)
    status = Column(String(20), nullable=False, default='processing')
    is_approved = Column(Boolean, nullable=False, default=False)
    error_message = Column(Text, nullable=True)
    feature_count = Column(Integer, nullable=True)
    geometry_type = Column(String(50), nullable=True)
    crs_original = Column(String(100), nullable=True)
    bbox = Column(JSON, nullable=True)
    validation_errors = Column(JSON, nullable=True)
    created_at = Column(
        DateTime, default=lambda: datetime.now(UTC), nullable=False
    )
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=True
    )

    def __init__(  # pylint: disable=too-many-arguments,R0917
        self,
        filename: str = '',
        file_type: str | None = None,
        file_size_kb: float | None = None,
        raw_s3_key: str | None = None,
        preview_s3_key: str | None = None,
        standard_s3_key: str | None = None,
        status: str = 'processing',
        is_approved: bool = False,
        error_message: str | None = None,
        feature_count: int | None = None,
        geometry_type: str | None = None,
        crs_original: str | None = None,
        bbox: dict | None = None,
        validation_errors: list | None = None,
    ):
        """Initialize the GeoDataUpload with all its fields."""
        super().__init__()
        self.filename = filename
        self.file_type = file_type
        self.file_size_kb = file_size_kb
        self.raw_s3_key = raw_s3_key
        self.preview_s3_key = preview_s3_key
        self.standard_s3_key = standard_s3_key
        self.status = status
        self.is_approved = is_approved
        self.error_message = error_message
        self.feature_count = feature_count
        self.geometry_type = geometry_type
        self.crs_original = crs_original
        self.bbox = bbox
        self.validation_errors = validation_errors

    def to_dict(self):
        """Return a dictionary representation of the model."""
        return {
            'id': self.id,
            'filename': self.filename,
            'file_type': self.file_type,
            'file_size_kb': self.file_size_kb,
            'raw_s3_key': self.raw_s3_key,
            'preview_s3_key': self.preview_s3_key,
            'standard_s3_key': self.standard_s3_key,
            'status': self.status,
            'is_approved': self.is_approved,
            'error_message': self.error_message,
            'feature_count': self.feature_count,
            'geometry_type': self.geometry_type,
            'crs_original': self.crs_original,
            'bbox': self.bbox,
            'validation_errors': self.validation_errors,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }
