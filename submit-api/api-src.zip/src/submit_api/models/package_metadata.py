"""Submission package model class.

Manages the package metadata
"""
from __future__ import annotations

import enum

from sqlalchemy import Column, ForeignKey

from .base_model import BaseModel
from .db import db


class PackageMetadataFields(enum.Enum):
    """Enum for package metadata fields."""

    CONSULTATION_CHECK_COMPLETED_ON = 'cc_completed_on'
    CONSULTATION_CHECK_START_DATE = 'cc_start_date'
    MAIN_CONDITION = 'main_condition'
    SUPPORTING_CONDITIONS = 'supporting_conditions'
    REVIEW_COMPLETED_ON = 'review_completed_on'
    REVIEW_START_DATE = 'review_start_date'


class PackageMetadata(BaseModel):
    """Definition of the package entity."""

    __tablename__ = 'package_metadata'

    id = Column(db.Integer, primary_key=True, autoincrement=True)
    package_id = Column(db.Integer, ForeignKey('packages.id', ondelete='CASCADE'), nullable=False, unique=True)
    json = Column(db.JSON)

    # add index on package_id
    __table_args__ = (
        db.Index('idx_package_id', 'package_id'),
    )

    @classmethod
    def get_by_package_id(cls, package_id: int):
        """Return model by package id."""
        return cls.query.filter_by(package_id=package_id).first()

    @classmethod
    def get_or_create(cls, package_id: int) -> PackageMetadata:
        """Get existing package metadata or create a new empty instance."""
        package_metadata = cls.get_by_package_id(package_id)
        if not package_metadata:
            package_metadata = cls(package_id=package_id, json={})
        return package_metadata
